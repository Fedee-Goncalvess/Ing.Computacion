# R-Info Multiplataforma

## Para Windows
> basta con instalar el archivo `Rinfo-2.7-windows.exe` haciendo doble click sobre el mismo

## Para Linux
> Para ejecutarlo vamos a trabajar desde la consola para iniciarla podes hacerlo con `Ctrl+Alt+t`.
>
> - Primero es necesario instalar la maquina virtual de java denominado JRE o Java Runtime Enviroment que provee todas las dependencias necesarias para ejecutar una aplicación java, esto lo pueden hacer ejecutando `sudo apt install default-jre` para ubuntu o debian, si tenes otra distro te recomendamos que busques como instalar la misma en tu SO.
> - Para ejecutar la aplicación hay que darle permisos de ejecución con el comando `chmod +x Rinfo-2.8-linux.jar` después de esto esta listo para ejecutarlo y eso se hace desde consola con `java -jar Rinfo-2.8-linux.jar`
