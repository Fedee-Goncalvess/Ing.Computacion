package servicios;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;
import clasesDAO.MonedaDAO;
import clasesDAOimp.MonedaDAOimp;
import modelos.moneda.*;

public class app {
	private static Scanner in = new Scanner(System.in); 
	private static final String URL = "jdbc:sqlite:billeteraBD.db"; //
	
	public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(URL)) {
            if (connection != null) {
               System.out.println("Conexión a la base de datos establecida.\n");
               
               ejecutarPrograma();
                

            }
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
    }

	private static void crearMoneda(){	
		imprimirCrearMoneda();
		int  x = in.nextInt();
		
		String nomenclatura;
		String nombre;
		double valorDolar;
		double stock;
		
		while (true) {
			switch (x) {
				case 1:
					System.out.println("Complete los campos");
					nomenclatura = completarNomenclatura();
					nombre = completarNombre();
					valorDolar = completarValorDolar();
					stock = completarStock();
					System.out.println();
					if(confirmarCampos()) {
						Moneda fiat = new FIAT(nomenclatura, nombre, valorDolar, stock);
						MonedaDAO dao = new MonedaDAOimp();
						try {
							dao.crearMoneda(fiat);
							System.out.println("Agregado a la base de datos");
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return;
					}
					System.out.println("Operación Cancelada");
					return;
					
				case 2:
					System.out.println("Complete los campos");
					nomenclatura = completarNomenclatura();
					nombre = completarNombre();
					valorDolar = completarValorDolar();
					stock = completarStock();
					double volatilidad = (Math.random() * 100);
					
					if(confirmarCampos()) {
						Moneda cripto = new Cripto(nomenclatura, nombre, valorDolar, stock, volatilidad);
						MonedaDAO dao = new MonedaDAOimp();
						try {
							dao.crearMoneda(cripto);
							System.out.println("Agregado a la base de datos");
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return;
					}
					System.out.println("Operación Cancelada\n");
					return;
					
				case 0:
					System.out.println("Operación Cancelada\n");
					return;
				default:
					System.out.println("Entrada incorrecta\n");
					imprimirCrearMoneda();
					x = in.nextInt();
					break;
			}	
		}
	}
	private static void imprimirCrearMoneda() {
		System.out.println("Indique el tipo de moneda a crear:");
		System.out.println(":FIAT [1]");
		System.out.println(":Cripto [2]");
		System.out.println(":Salir [0]\n");
	}
	private static void listarMoneda(){
		System.out.println();
	}
	private static void generarStock(){
		System.out.println();
	}
	private static void listarStock(){
		System.out.println();
	}
	private static void generarActivos(){
		System.out.println();
	}
	private static void listarActivos(){
		System.out.println();
	}
	private static void comprarCripto(){
		System.out.println();
	}
	private static void swap(){
		System.out.println();
	}
	
	private static String completarNombre() {
		System.out.println("Nombre: ");
		return in.next();
	}
	private static String completarNomenclatura() {
		System.out.println("Nomenclatura: ");
		return in.next();
	}
	private static double completarValorDolar() {
		System.out.println("valor en Dolar: ");
		return in.nextDouble();
	}
	private static double completarStock() {
		System.out.println("Stock: ");
		return in.nextDouble();
	}
	private static boolean confirmarCampos() {
		System.out.println("Confirmar campos [y/n]");
		String entrada = in.next();
		while (true){
			switch (entrada) {
			case "y":
				return true;
			case "n":
				return false;
			default:
				System.out.println("Entrada incorrecta");
				System.out.println("Confirmar campos [y/n]");
				entrada = in.next();
				break;
			}
		}
	}
	
	private static void imprimirTerminal() {
		System.out.println("--Ingrese función a ejecutar--\n");
		System.out.println("[1].Crear Moneda");
		System.out.println("[2].Listar Monedas");
		System.out.println("[3].Generar Stock");
		System.out.println("[4].Listar Stock");
		System.out.println("[5].Generar Mis Activos");
		System.out.println("[6].Listar Mis Activos");
		System.out.println("[7].Comprar Criptomoneda");
		System.out.println("[8].Swap Criptomoneda");
		System.out.println("[0].Terminar programa");
	}
	
	private static void ejecutarPrograma() {
		imprimirTerminal(); 
        int comando = in.nextInt();
        
        while (comando!= 0) {
        	switch(comando) {
        	case 1:
        		crearMoneda();
        		break;
        	case 2:
        		listarMoneda();
        		break;
        	case 3:
        		generarStock();
        		break;
        	case 4:
        		listarStock();
        		break;
        	case 5:
        		generarActivos();
        		break;
        	case 6:
        		listarActivos();
        		break;
        	case 7:
        		comprarCripto();
        		break;
        	case 8:
        		swap();
        		break;
        	}
        	imprimirTerminal();
        	comando = in.nextInt();
        }
        System.out.println("Programa Terminado");
	}
}